"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var frameModule = require("ui/frame");
var http = require("http");
var firebase = require("nativescript-plugin-firebase");
var appSettings = require('application-settings');
var keys = require('../keys');
// import {
//   MLKitRecognizeTextOnDeviceResult,
//   MLKitRecognizeTextResultBlock
// } from 'nativescript-plugin-firebase/mlkit/textrecognition';
// import { MLKitScanBarcodesOnDeviceResult } from 'nativescript-plugin-firebase/mlkit/barcodescanning';
var scanCount = 0;
function navigatedTo() {
    scanCount = 0;
    // android back button hack
    appSettings.setString('pageSource', './scan/scan-page');
}
exports.navigatedTo = navigatedTo;
function goBack(args) {
    var navigationOptions = {
        moduleName: './start/start-page',
        transition: {
            name: 'slideBottom',
            clearHistory: true
        }
    };
    frameModule.topmost().navigate(navigationOptions);
}
exports.goBack = goBack;
// export function onTextRecognitionResult(scanResult: any): void {
//   const value: MLKitRecognizeTextOnDeviceResult = scanResult.value;
//   vm.set('blocks', value.blocks);
// }
function onBarcodeScanningResult(scanResult) {
    if (scanResult.value.barcodes.length > 0 && scanCount == 0) {
        scanCount++;
        var code = scanResult.value.barcodes[0].value;
        // let url = 'https://api.upcdatabase.org/product/' + code + '/' + '';
        var url = keys.upcUrl + '?code=' + code + '&test=' + keys.test;
        http.getJSON(url).then(function (u) {
            if (u.id == null) {
                alert({
                    title: 'Sorry!',
                    message: "Couldn't find that beer!",
                    okButtonText: 'OK',
                    cancelable: false
                });
                return;
            }
            var navigationOptions = {
                moduleName: './detail/detail-page',
                context: {
                    id: u.id,
                    name: u.name,
                    score: u.score,
                    image: u.image,
                    image_lg: '',
                    brewery: u.brewery,
                    style: u.style,
                    desc: u.desc,
                    abv: u.abv,
                    ibu: u.ibu,
                    count: u.score_count,
                    score_img_1: 'rating-detail ' + u.score_img_1,
                    score_img_2: 'rating-detail ' + u.score_img_2,
                    score_img_3: 'rating-detail ' + u.score_img_3,
                    score_img_4: 'rating-detail ' + u.score_img_4,
                    score_img_5: 'rating-detail ' + u.score_img_5
                }
            };
            frameModule.topmost().navigate(navigationOptions);
        }, function (error) {
            //console.error('ERROR: ' + error);
            firebase.sendCrashLog({
                message: 'Error with UPC scanning: ' + error,
                showInConsole: true
            });
        });
    }
}
exports.onBarcodeScanningResult = onBarcodeScanningResult;
