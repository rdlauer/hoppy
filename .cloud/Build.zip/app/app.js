"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("./bundle-config");
var application = require("application");
var firebase = require("nativescript-plugin-firebase");
var frameModule = require("ui/frame");
firebase
    .init({})
    .then(function (instance) {
    console.log('firebase.init done');
}, function (error) {
    //console.log(`firebase.init error: ${error}`);
    firebase.sendCrashLog({
        message: "Error initializing firebase: " + error,
        showInConsole: true
    });
});
// android back button hack
if (application.android) {
    application.android.on(application.AndroidApplication.activityBackPressedEvent, backEvent);
}
function backEvent(args) {
    var currentPage = frameModule.topmost().currentPage;
    if (currentPage &&
        currentPage.exports &&
        typeof currentPage.exports.backEvent === 'function') {
        currentPage.exports.backEvent(args);
    }
}
application.run({ moduleName: 'app-root' });
