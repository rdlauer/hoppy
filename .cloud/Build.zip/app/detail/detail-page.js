"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var frame_1 = require("ui/frame");
var nativescript_appavailability_1 = require("nativescript-appavailability");
var utils_1 = require("tns-core-modules/utils/utils");
var platform_1 = require("tns-core-modules/platform");
var frameModule = require("ui/frame");
var observableModule = require('tns-core-modules/data/observable');
var vm = new observableModule.Observable();
var appSettings = require('application-settings');
var page, cpAbv, cpIbu, id;
function goBack(args) {
    frame_1.topmost().goBack();
}
exports.goBack = goBack;
function backEvent(args) {
    // this is a hack for android as i am having trouble with a cached version of the page not showing up without actually navigating to the page again...
    var module = './main/main-page';
    if (appSettings.getString('pageSource')) {
        module = appSettings.getString('pageSource');
    }
    var navigationOptions = {
        moduleName: module,
        transition: {
            name: 'slideRight'
        }
    };
    frameModule.topmost().navigate(navigationOptions);
    args.cancel = true;
}
exports.backEvent = backEvent;
function pageLoaded(args) {
    page = args.object;
    page.bindingContext = vm;
    cpAbv = page.getViewById('cpAbv');
    cpIbu = page.getViewById('cpIbu');
    var context = page.navigationContext;
    id = context.id;
    vm.set('name', context.name);
    vm.set('score', context.score);
    vm.set('image', context.image_lg || context.image);
    vm.set('brewery', context.brewery);
    vm.set('style', context.style);
    vm.set('desc', context.desc);
    vm.set('abv', context.abv);
    vm.set('ibu', context.ibu);
    vm.set('score_count', context.score_count);
    vm.set('score_img_1', context.score_img_1);
    vm.set('score_img_2', context.score_img_2);
    vm.set('score_img_3', context.score_img_3);
    vm.set('score_img_4', context.score_img_4);
    vm.set('score_img_5', context.score_img_5);
    //no idea why this has to be in a setTimeout to work???
    setTimeout(function () {
        if (typeof cpAbv.update === 'function') {
            cpAbv.update(30, parseFloat(parseFloat(context.abv).toFixed(2)));
        }
    }, 50);
    setTimeout(function () {
        if (typeof cpIbu.update === 'function') {
            cpIbu.update(70, parseInt(context.ibu));
        }
    }, 50);
}
exports.pageLoaded = pageLoaded;
function openUntappd() {
    var url, message;
    var urlScheme = platform_1.isIOS ? 'untappd://' : 'com.untappdllc.app';
    if (nativescript_appavailability_1.availableSync(urlScheme)) {
        //message = "using app";
        url = 'untappd://beer/' + id;
    }
    else {
        //message = "browser";
        url = 'https://untappd.com/b/---/' + id;
    }
    utils_1.openUrl(url);
}
exports.openUntappd = openUntappd;
