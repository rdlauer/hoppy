"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var frameModule = require("ui/frame");
var platform_1 = require("tns-core-modules/platform");
var appSettings = require('application-settings');
var modalPageModule = './login-modal/login-modal';
var context = '';
var fullscreen = true;
var page;
function pageLoaded(args) {
    page = args.object;
    //crash();
}
exports.pageLoaded = pageLoaded;
function openBrowser(args) {
    // check to see if this user has already successfully authenticated
    var token = appSettings.getString('untappdToken');
    if (token && token.length > 0) {
        var navigationOptions = {
            moduleName: './start/start-page',
            transition: {
                name: 'slideTop'
            }
        };
        frameModule.topmost().navigate(navigationOptions);
    }
    else {
        page.showModal(modalPageModule, context, function (token) {
            // Receive data from the modal page
        }, fullscreen);
    }
}
exports.openBrowser = openBrowser;
function crash() {
    // this is just to force a crash to see if crashlytics is working!
    if (platform_1.isIOS) {
        Crashlytics.sharedInstance().crash();
    }
}
