"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var frameModule = require("ui/frame");
var webViewModule = require('tns-core-modules/ui/web-view');
var appSettings = require('application-settings');
var firebase = require("nativescript-plugin-firebase");
function onWebViewLoaded(webargs) {
    var page = webargs.object.page;
    var webview = webargs.object;
    webview.on(webViewModule.WebView.loadFinishedEvent, function (args) {
        if (!args.error) {
            if (args.url.includes('#access_token')) {
                // successful auth!
                var token = args.url.replace('https://hoppyapp.com/auth.html#access_token=', '');
                appSettings.setString('untappdToken', token);
                closeCallback(token);
                var navigationOptions = {
                    moduleName: './start/start-page',
                    transition: {
                        name: 'slideTop'
                    }
                };
                frameModule.topmost().navigate(navigationOptions);
            }
        }
        else {
            //console.log(args.error);
            firebase.sendCrashLog({
                message: 'Error authenticating user: ' + args.error,
                showInConsole: true
            });
        }
    });
}
exports.onWebViewLoaded = onWebViewLoaded;
var context;
var closeCallback;
function onShowingModally(args) {
    context = args.context;
    closeCallback = args.closeCallback;
}
exports.onShowingModally = onShowingModally;
