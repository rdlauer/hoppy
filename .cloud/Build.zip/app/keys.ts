let keys = {
  searchUrl: 'https://hoppyapp.com/api/beer/getbeersearch',
  upcUrl: 'https://hoppyapp.com/api/beer/getupc',
  upcDatabaseKey: '30FC3EC36044BFB0BE271359638B7D3C',
  test: false
};

module.exports = keys;

// tns build android --release --key-store-path /Users/rob/Documents/apps/keystores/hoppy.jks --key-store-password Bullshit4u! --key-store-alias Hoppy --key-store-alias-password Bullshit4u!
