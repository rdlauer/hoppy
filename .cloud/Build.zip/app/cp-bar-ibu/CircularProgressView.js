const CircularProgressBarViewModel = require('./circular-progress-bar-view-model');

exports.onLoaded = function(args) {
  const circularProgressBarVm = new CircularProgressBarViewModel();
  args.object.bindingContext = circularProgressBarVm;

  args.object.update = function(cpSize, cpProgress) {
    circularProgressBarVm.height = 140; //Math.min(cpSize, 250);
    circularProgressBarVm.textSize = 22; //circularProgressBarVm.height / 3.5;

    circularProgressBarVm.progress = Math.min((cpProgress * 100) / 70, 100);
    //circularProgressBarVm.text = `${circularProgressBarVm.progress} IBU`;
    circularProgressBarVm.text = `${cpProgress} IBU`;
  };
};
