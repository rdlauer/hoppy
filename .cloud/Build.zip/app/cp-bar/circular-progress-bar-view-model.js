const observableModule = require('data/observable');

function CircularProgressBarViewModel() {
  var viewModel = observableModule.fromObject({
    offset: 0,
    textColor: '#545454',
    fillColor: '#629740',
    fillBackgroundColor: '#efeff4',
    height: 200,
    progress: 0,
    text: `${0}%`,
    textSize: 100 / 3.5
  });

  return viewModel;
}

module.exports = CircularProgressBarViewModel;
