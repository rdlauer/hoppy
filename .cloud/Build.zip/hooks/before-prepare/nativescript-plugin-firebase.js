module.exports = require("nativescript-plugin-firebase/scripts/entitlements-before-prepare.js");
