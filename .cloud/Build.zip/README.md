# Hoppy

Snap a pic of a drink menu and Hoppy will provide you Untappd ratings for each beer!

Built with [NativeScript](https://www.nativescript.org/) and the [Untappd API](https://untappd.com/api/docs).

Available on the [iOS App Store](https://itunes.apple.com/us/app/hoppy-discover-beer-ratings/id1406526158?ls=1&mt=8) and on [Google Play](https://play.google.com/store/apps/details?id=org.nativescript.hoppy).

![hoppy screens](readme.png)
